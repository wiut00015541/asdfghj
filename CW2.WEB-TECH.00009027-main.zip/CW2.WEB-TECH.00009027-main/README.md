********  TO LIST APPLICATION ************

This app allows users to add some List of data.

********* Intructions ***************

1.Download the source code

```bash
git clone https://github.com/00009027/CW2.WEB-TECH.00009027.git
```
or just download the *.zip file

2. For running the application firstly install "node_modules"
```bash
npm install
```

3.Run the app
```bash
node app
```

************* Main purpose of this application *****************

This application let users to add or delete data


********** Link to github repo ************

https://github.com/00009027/CW2.WEB-TECH.00009027.git

*********** Link to application on Glitch *****************

https://ulquiorra4.glitch.me




